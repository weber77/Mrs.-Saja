
numberList = []
i = 0
while i < 5:
    print("Enter a Number: ", end="")
    numberList.append(int(input())**2)
    i += 1


print(numberList)